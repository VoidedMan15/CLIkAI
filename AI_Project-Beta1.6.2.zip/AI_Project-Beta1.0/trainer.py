import json
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments
from datasets import Dataset

# Define sentiment categories (MUST match your training data)
sentiment_categories = [
        "Admiration", "Amusement", "Anger", "Annoyance", "Approval", "Boredom", "Calmness", "Confusion", 
        "Curiosity", "Desire", "Disappointment", "Disapproval", "Disgust", "Embarrassment", "Excitement", 
        "Fear", "Gratitude", "Grief", "Hope", "Joy", "Love", "Nostalgia", "Optimism", "Pessimism", 
        "Pride", "Realization", "Relief", "Remorse", "Sadness", "Satisfaction", "Shame", "Surprise", 
        "Sympathy", "Tiredness", "Trust", "Anticipation", "Awe", "Contentment", "Disillusionment", 
        "Doubt", "Envy", "Frustration", "Guilt", "Interest", "Jealousy", "Loneliness", "Regret", 
        "Resentment", "Serenity", "Worry"
    ]

# Load feedback dataset
with open("feedback_dataset.json", "r") as f:
    feedback_data = json.load(f)

# Convert to Hugging Face dataset
dataset = Dataset.from_dict({
    "text": [item["text"] for item in feedback_data],
    "label": [sentiment_categories.index(item["correct_sentiment"]) for item in feedback_data]
})

# Load model with mismatch handling
tokenizer = AutoTokenizer.from_pretrained("bhadresh-savani/distilbert-base-uncased-emotion")
model = AutoModelForSequenceClassification.from_pretrained(
    "bhadresh-savani/distilbert-base-uncased-emotion",
    num_labels=len(sentiment_categories),
    ignore_mismatched_sizes=True  # Critical fix
)

def tokenize_function(examples):
    return tokenizer(examples["text"], padding="max_length", truncation=True, max_length=128)

tokenized_dataset = dataset.map(tokenize_function, batched=True)

# Define training arguments
training_args = TrainingArguments(
    output_dir="./results",
    evaluation_strategy="epoch",
    learning_rate=2e-5,
    per_device_train_batch_size=16,
    num_train_epochs=3,
    weight_decay=0.01,
)

# Initialize the Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_dataset,
    eval_dataset=tokenized_dataset,
)

# Fine-tune the model
trainer.train()