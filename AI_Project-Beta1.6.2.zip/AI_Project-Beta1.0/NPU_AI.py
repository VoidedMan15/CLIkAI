import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification, AutoModelForQuestionAnswering
from openvino import Core, serialize
import numpy as np
import os
import time
import json
import subprocess
import socket
import logging
from pathlib import Path
import re  # For basic math detection

# Configure logging
logging.basicConfig(
    filename="sentiment_analysis.log",
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Sentiment categories (for sentiment mode)
sentiment_categories = [
    "Admiration", "Amusement", "Anger", "Annoyance", "Approval", "Boredom", "Calmness", "Confusion", 
    "Curiosity", "Desire", "Disappointment", "Disapproval", "Disgust", "Embarrassment", "Excitement", 
    "Fear", "Gratitude", "Grief", "Hope", "Joy", "Love", "Nostalgia", "Optimism", "Pessimism", 
    "Pride", "Realization", "Relief", "Remorse", "Sadness", "Satisfaction", "Shame", "Surprise", 
    "Sympathy", "Tiredness", "Trust", "Anticipation", "Awe", "Contentment", "Disillusionment", 
    "Doubt", "Envy", "Frustration", "Guilt", "Interest", "Jealousy", "Loneliness", "Regret", 
    "Resentment", "Serenity", "Worry"
]

# Menu options
modes = {
    "1": {
        "name": "Sentiment Analysis Mode",
        "description": "Analyze the sentiment of text with advanced NLP models.",
        "models": {
            "1": {"name": "BERT (DistilBERT)", "model": "bhadresh-savani/distilbert-base-uncased-emotion", "desc": "Fast and lightweight BERT model for sentiment analysis."},
            "2": {"name": "RoBERTa", "model": "j-hartmann/emotion-english-distilroberta-base", "desc": "Robust model with 7 emotions, mapped to 50-label set."},
            "3": {"name": "ALBERT", "model": "textattack/albert-base-v2-yelp-polarity", "desc": "Efficient model, adapted for sentiment with fine-tuning."}
        }
    },
    "2": {
        "name": "Question Answering Mode",
        "description": "Extract answers from provided context text using QA models (Note: Answers must be in the context).",
        "models": {
            "1": {"name": "DistilBERT QA", "model": "distilbert-base-uncased-distilled-squad", "desc": "Lightweight QA model trained on SQuAD."},
            "2": {"name": "RoBERTa QA", "model": "deepset/roberta-base-squad2", "desc": "High-accuracy QA model for complex questions."},
            "3": {"name": "ELECTRA QA", "model": "ahotrod/electra_large_discriminator_squad2_512", "desc": "Powerful QA model with large capacity."}
        }
    }
}

# Check internet connection
def is_online():
    try:
        socket.create_connection(("www.google.com", 80), timeout=2)
        logger.info("Internet connection detected.")
        return True
    except OSError:
        logger.warning("No internet connection detected.")
        return False

# Check if model is downloaded
def is_model_downloaded(model_name, local_path=None):
    default_path = Path.home() / ".cache" / "huggingface" / "hub" / f"models--{model_name.replace('/', '--')}"
    check_path = local_path if local_path else default_path
    required_files = ["config.json", "pytorch_model.bin"]
    if os.path.exists(check_path):
        return all(os.path.exists(check_path / file) for file in required_files)
    return False

# Display menu and get user choice
def display_menu():
    print("\n=== Model Selection Menu ===")
    for mode_key, mode_info in modes.items():
        print(f"{mode_key}. {mode_info['name']}: {mode_info['description']}")
        for model_key, model_info in mode_info["models"].items():
            print(f"   {mode_key}.{model_key} - {model_info['name']}: {model_info['desc']}")
    print("\nEnter your choice (e.g., '1.1' for Sentiment BERT, '2.2' for QA RoBERTa): ")
    choice = input().strip()
    return choice

# Parse user choice
def parse_choice(choice):
    try:
        mode_key, model_key = choice.split(".")
        if mode_key in modes and model_key in modes[mode_key]["models"]:
            return mode_key, model_key
        else:
            raise ValueError("Invalid mode or model selection.")
    except ValueError:
        logger.error(f"Invalid choice: {choice}")
        print("Invalid choice. Defaulting to Sentiment BERT (1.1).")
        return "1", "1"

# Sentiment-specific functions (unchanged for brevity, assume fixed from previous version)
def export_onnx_model(model_name):
    if not is_model_downloaded(model_name) and not is_online():
        logger.error(f"Model '{model_name}' not downloaded and no internet connection. Cannot proceed.")
        raise RuntimeError("Model not downloaded and offline. Please connect to the internet to download it once.")
    elif not is_model_downloaded(model_name):
        logger.info(f"Model '{model_name}' not found locally. Downloading now...")
    
    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=len(sentiment_categories), ignore_mismatched_sizes=True)
        inputs = tokenizer(
            "Sample text",
            padding="max_length",
            max_length=128,
            truncation=True,
            return_tensors="pt"
        )
        torch.onnx.export(
            model,
            (inputs["input_ids"], inputs["attention_mask"]),
            "bert_classifier.onnx",
            opset_version=14,
            input_names=["input_ids", "attention_mask"],
            output_names=["logits"],
            dynamic_axes=None
        )
        logger.info("ONNX model exported to bert_classifier.onnx")
    except Exception as e:
        logger.error(f"Error exporting ONNX model for {model_name}: {str(e)}")
        raise

def update_openvino_model(checkpoint_path, model_name):
    if not os.path.exists(checkpoint_path):
        logger.warning(f"Checkpoint directory '{checkpoint_path}' does not exist. Skipping update.")
        return False

    config_path = Path(checkpoint_path) / "config.json"
    model_path = Path(checkpoint_path) / "model.safetensors"
    
    if not os.path.exists(config_path) or not os.path.exists(model_path):
        logger.warning(f"Required files (config.json or model.safetensors) not found in '{checkpoint_path}'. Skipping update.")
        return False

    if not is_model_downloaded(model_name) and not is_online():
        logger.error(f"Model '{model_name}' not downloaded and no internet connection. Cannot proceed.")
        raise RuntimeError("Model not downloaded and offline. Please connect to the internet to download it once.")
    elif not is_model_downloaded(model_name):
        logger.info(f"Model '{model_name}' not found locally. Downloading now...")

    try:
        tokenizer = AutoTokenizer.from_pretrained(model_name)
        model = AutoModelForSequenceClassification.from_pretrained(
            model_name,
            num_labels=len(sentiment_categories),
            ignore_mismatched_sizes=True
        )
        # Note: Skipping checkpoint loading for simplicity; adjust if compatible checkpoint exists
        inputs = tokenizer(
            "Sample text",
            padding="max_length",
            max_length=128,
            truncation=True,
            return_tensors="pt"
        )
        torch.onnx.export(
            model,
            (inputs["input_ids"], inputs["attention_mask"]),
            "bert_classifier_finetuned.onnx",
            opset_version=14,
            input_names=["input_ids", "attention_mask"],
            output_names=["logits"],
            dynamic_axes=None
        )
        ov_output_dir = "ov_model"
        os.makedirs(ov_output_dir, exist_ok=True)
        command = [
            "python",
            "-m",
            "openvino.tools.ovc",
            "bert_classifier_finetuned.onnx",
            "--output_model", f"{ov_output_dir}/bert.xml",
            "--input", "input_ids[1,128],attention_mask[1,128]",
            "--compress_to_fp16"
        ]
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode != 0:
            logger.error(f"OVC Conversion Failed: {result.stderr}")
            return False
        core = Core()
        compiled_model = core.compile_model(f"{ov_output_dir}/bert.xml", "CPU")
        logger.info("Successfully updated OpenVINO model with:")
        logger.info(f"- Inputs: {compiled_model.inputs}")
        logger.info(f"- Outputs: {compiled_model.outputs}")
        return True
    except Exception as e:
        logger.error(f"Error updating OpenVINO model for {model_name} with checkpoint {checkpoint_path}: {str(e)}")
        return False

def find_latest_checkpoint(results_dir="results"):
    if not os.path.exists(results_dir):
        logger.warning(f"Results directory '{results_dir}' does not exist. No checkpoints found.")
        return None

    checkpoints = [d for d in os.listdir(results_dir) if d.startswith("checkpoint")]
    if not checkpoints:
        logger.warning(f"No checkpoints found in '{results_dir}'.")
        return None

    latest_checkpoint = max(checkpoints, key=lambda x: int(x.split("-")[1]))
    logger.info(f"Latest checkpoint found: {latest_checkpoint}")
    return str(Path(results_dir) / latest_checkpoint)

def convert_to_openvino():
    os.makedirs("ov_model", exist_ok=True)
    command = [
        "python",
        "-m",
        "openvino.tools.ovc",
        "bert_classifier.onnx",
        "--output_model", "ov_model/bert.xml",
        "--input", "input_ids[1,128],attention_mask[1,128]",
        "--compress_to_fp16"
    ]
    result = subprocess.run(command, capture_output=True, text=True)
    if result.returncode != 0:
        logger.error(f"OVC Conversion Failed: {result.stderr}")
        raise RuntimeError("OVC conversion failed. Check logs for details.")
    logger.info("OpenVINO model saved to ov_model/bert.xml and ov_model/bert.bin")

def get_baseline_sentiment(text, baseline_model):
    if not is_model_downloaded(baseline_model) and not is_online():
        logger.warning(f"Baseline model '{baseline_model}' not downloaded and no internet connection. Skipping baseline.")
        return "N/A", 0.0
    elif not is_model_downloaded(baseline_model):
        logger.info(f"Baseline model '{baseline_model}' not found locally. Downloading now...")

    tokenizer = AutoTokenizer.from_pretrained(baseline_model)
    model = AutoModelForSequenceClassification.from_pretrained(baseline_model)
    inputs = tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=128)
    with torch.no_grad():
        outputs = model(**inputs)
        probabilities = torch.nn.functional.softmax(outputs.logits, dim=-1)
        predicted_class = torch.argmax(probabilities, dim=-1).item()
        confidence = probabilities[0][predicted_class].item()
    sentiment_labels = ["anger", "disgust", "fear", "joy", "neutral", "sadness", "surprise"]
    mapped_sentiment = map_baseline_to_categories(sentiment_labels[predicted_class])
    logger.info(f"Baseline sentiment for '{text}': {mapped_sentiment} ({confidence:.2%})")
    return mapped_sentiment, confidence

def map_baseline_to_categories(baseline_sentiment):
    mapping = {
        "anger": "Anger",
        "disgust": "Disgust",
        "fear": "Fear",
        "joy": "Joy",
        "neutral": "Calmness",
        "sadness": "Sadness",
        "surprise": "Surprise"
    }
    return mapping.get(baseline_sentiment.lower(), "Unknown")

def run_sentiment_inference(model_name, baseline_model):
    core = Core()
    if not is_model_downloaded(model_name) and not is_online():
        logger.error(f"Model '{model_name}' not downloaded and no internet connection. Cannot proceed.")
        raise RuntimeError("Model not downloaded and offline. Please connect to the internet to download it once.")
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    feedback_dataset_file = "feedback_dataset.json"
    if os.path.exists(feedback_dataset_file):
        try:
            with open(feedback_dataset_file, "r") as f:
                dataset = json.load(f)
        except json.JSONDecodeError:
            logger.warning("feedback_dataset.json is empty or contains invalid JSON. Initializing with an empty dataset.")
            dataset = []
    else:
        logger.info("feedback_dataset.json does not exist. Initializing with an empty dataset.")
        dataset = []

    input_text = input("\nEnter text to analyze sentiment: ")
    logger.info(f"User input text: '{input_text}'")

    baseline_sentiment, baseline_confidence = get_baseline_sentiment(input_text, baseline_model)

    inputs = tokenizer(
        input_text,
        padding="max_length",
        max_length=128,
        truncation=True,
        return_tensors="np"
    )

    available_devices = core.available_devices
    logger.info(f"Available devices: {available_devices}")
    print(f"\nAvailable devices: {available_devices}")

    target_devices = ['NPU', 'GPU', 'CPU']
    results = []

    for device in target_devices:
        if device in available_devices:
            try:
                compiled_model = core.compile_model("ov_model/bert.xml", device)
                _ = compiled_model({"input_ids": inputs["input_ids"], "attention_mask": inputs["attention_mask"]})
                start_time = time.perf_counter()
                result = compiled_model({"input_ids": inputs["input_ids"], "attention_mask": inputs["attention_mask"]})
                latency = (time.perf_counter() - start_time) * 1000
                logits = result[0]
                probabilities = torch.nn.functional.softmax(torch.tensor(logits), dim=-1)
                predicted_class = torch.argmax(probabilities, dim=-1).item()
                confidence = probabilities.squeeze().tolist()[predicted_class]
                results.append({
                    'device': device,
                    'sentiment': sentiment_categories[predicted_class],
                    'confidence': confidence,
                    'latency': latency,
                    'probabilities': probabilities.squeeze().tolist()
                })
                logger.info(f"Inference on {device}: {sentiment_categories[predicted_class]} ({confidence:.2%}), Latency: {latency:.2f} ms")
            except Exception as e:
                logger.error(f"Error running on {device}: {str(e)}")

    print(f"\nAnalysis of: '{input_text}'")
    print("\n=== Baseline Prediction (DistilRoBERTa) ===")
    print(f"Sentiment:  {baseline_sentiment}")
    print(f"Confidence: {baseline_confidence:.2%}")
    print("\n=== Fine-Tuned Model Performance Comparison ===")
    print(f"{'Device':<8} | {'Sentiment':<10} | {'Confidence':<12} | {'Latency (ms)':<12}")
    print("--------------------------------------------------")
    
    best_result = None
    for result in results:
        print(f"{result['device']:<8} | {result['sentiment']:<10} | {result['confidence']:.2%}       | {result['latency']:.2f}")
        if not best_result or (abs(result['confidence'] - best_result['confidence']) < 0.001 and result['latency'] < best_result['latency']) or \
           (result['confidence'] > best_result['confidence']):
            best_result = result

    if best_result:
        print("\n=== Optimal Fine-Tuned Result ===")
        print(f"Device:     {best_result['device']}")
        print(f"Sentiment:  {best_result['sentiment']}")
        print(f"Confidence: {best_result['confidence']:.2%}")
        print(f"Speed:      {best_result['latency']:.2f} ms")
        logger.info(f"Optimal result: {best_result['device']}, {best_result['sentiment']}, {best_result['confidence']:.2%}, {best_result['latency']:.2f} ms")
    else:
        logger.warning("No successful inferences!")
        print("\nNo successful inferences!")
        return

    print("\n=== Sentiment Selection ===")
    print(f"Baseline Suggestion: {baseline_sentiment} ({baseline_confidence:.2%})")
    print("Available sentiments: Admiration, Amusement, Anger, ...")
    correct_sentiment = input("Enter the correct sentiment for this text (or press Enter to accept baseline): ").capitalize()
    if not correct_sentiment:
        correct_sentiment = baseline_sentiment if baseline_sentiment != "N/A" else "Unknown"
        logger.info(f"User accepted baseline sentiment: {correct_sentiment}")
    elif correct_sentiment not in sentiment_categories:
        logger.warning(f"'{correct_sentiment}' is not in the list. Saving as provided.")
        print(f"'{correct_sentiment}' is not in the list. Saving as provided.")
    
    entry = {
        "text": input_text,
        "predicted_sentiment": best_result['sentiment'],
        "correct_sentiment": correct_sentiment,
        "confidence": f"{best_result['confidence']:.2%}",
        "device": best_result['device'],
        "latency": f"{best_result['latency']:.2f} ms",
        "baseline_sentiment": baseline_sentiment,
        "baseline_confidence": f"{baseline_confidence:.2%}"
    }
    existing_idx = next((i for i, item in enumerate(dataset) 
                        if item["text"] == input_text and item["device"] == best_result['device']), None)
    if existing_idx is not None:
        dataset[existing_idx] = entry
    else:
        dataset.append(entry)
    with open(feedback_dataset_file, "w") as f:
        json.dump(dataset, f, indent=4)
    logger.info("Feedback saved to dataset.")
    print("Feedback saved to dataset.")

    logger.info("Running trainer.py to fine-tune model with updated feedback.")
    print("Fine-tuning model with updated feedback...")
    result = subprocess.run(["python", "trainer.py"], capture_output=True, text=True)
    if result.returncode == 0:
        logger.info("Trainer.py executed successfully.")
        print("Model fine-tuning completed successfully.")
        latest_checkpoint = find_latest_checkpoint()
        if latest_checkpoint:
            logger.info(f"Updating OpenVINO model with latest checkpoint: {latest_checkpoint}")
            update_openvino_model(latest_checkpoint, model_name)
    else:
        logger.error(f"Trainer.py failed: {result.stderr}")
        print(f"Error during fine-tuning: {result.stderr}")

# QA-specific function with improvements
def run_qa_inference(model_name):
    if not is_model_downloaded(model_name) and not is_online():
        logger.error(f"Model '{model_name}' not downloaded and no internet connection. Cannot proceed.")
        raise RuntimeError("Model not downloaded and offline. Please connect to the internet to download it once.")
    elif not is_model_downloaded(model_name):
        logger.info(f"Model '{model_name}' not found locally. Downloading now...")

    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForQuestionAnswering.from_pretrained(model_name)

    context = input("\nEnter the context text (the text containing the answer): ")
    question = input("Enter your question: ")
    logger.info(f"QA input - Context: '{context}', Question: '{question}'")

    # Basic arithmetic check
    math_match = re.match(r"What is (\d+) \+ (\d+)", question.strip(), re.IGNORECASE)
    if math_match and not any(char.isdigit() for char in context):
        num1, num2 = map(int, math_match.groups())
        answer = str(num1 + num2)
        print(f"\nAnswer: {answer} (Calculated, not found in context)")
        logger.info(f"QA output - Answer: '{answer}' (Calculated)")
    else:
        inputs = tokenizer(question, context, return_tensors="pt", truncation=True, max_length=512)
        with torch.no_grad():
            outputs = model(**inputs)
            answer_start = torch.argmax(outputs.start_logits)
            answer_end = torch.argmax(outputs.end_logits) + 1
            answer = tokenizer.convert_tokens_to_string(
                tokenizer.convert_ids_to_tokens(inputs["input_ids"][0][answer_start:answer_end])
            )
            # Handle uninformative answers
            if answer in ["[CLS]", "[SEP]", ""] or answer.strip() == "":
                answer = "I couldn't find the answer in the provided context."
                logger.info(f"QA output - No valid answer found in context")
            else:
                logger.info(f"QA output - Answer: '{answer}'")
            print(f"\nAnswer: {answer}")

# Main execution
if __name__ == "__main__":
    try:
        choice = display_menu()
        mode_key, model_key = parse_choice(choice)
        selected_mode = modes[mode_key]
        selected_model = selected_mode["models"][model_key]["model"]
        logger.info(f"Selected mode: {selected_mode['name']}, Model: {selected_model}")

        if mode_key == "1":  # Sentiment Analysis Mode
            latest_checkpoint = find_latest_checkpoint()
            if latest_checkpoint:
                logger.info(f"Found latest checkpoint: {latest_checkpoint}")
                print(f"Found latest checkpoint: {latest_checkpoint}")
                if update_openvino_model(latest_checkpoint, selected_model):
                    logger.info("Successfully updated OpenVINO model with fine-tuned weights!")
                    print("Successfully updated OpenVINO model with fine-tuned weights!")
                else:
                    logger.warning("Failed to update OpenVINO model, falling back to pre-trained model")
                    print("Failed to update OpenVINO model, falling back to pre-trained model")
                    export_onnx_model(selected_model)
                    convert_to_openvino()
            else:
                logger.info("No checkpoints found, using pre-trained model")
                print("No checkpoints found, using pre-trained model")
                export_onnx_model(selected_model)
                convert_to_openvino()
            run_sentiment_inference(selected_model, "j-hartmann/emotion-english-distilroberta-base")
        
        elif mode_key == "2":  # Question Answering Mode
            run_qa_inference(selected_model)

    except RuntimeError as e:
        logger.error(f"Runtime error: {str(e)}")
        print(f"Error: {str(e)}")
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        print(f"Unexpected error: {str(e)}")