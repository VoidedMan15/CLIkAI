// Create a shell object
var shell = new ActiveXObject("WScript.Shell");

// Custom trim function for JScript compatibility
function trim(str) {
    return str.replace(/^\s+|\s+$/g, "");
}

// Function to run a command and display output with a timeout, returning output
function runCommand(command, timeoutSeconds) {
    var exec = shell.Exec("powershell.exe -NoProfile -Command \"" + command + "\"");
    var startTime = new Date().getTime();
    var timeoutMillis = timeoutSeconds * 1000;
    var output = "";
    var error = "";

    // Wait for command to finish or timeout
    while (exec.Status == 0) {
        var elapsed = new Date().getTime() - startTime;
        if (elapsed > timeoutMillis) {
            exec.Terminate();
            WScript.StdErr.WriteLine("Command timed out after " + timeoutSeconds + " seconds.");
            return { exitCode: 1, output: output, error: error };
        }
        if (!exec.StdOut.AtEndOfStream) {
            var line = exec.StdOut.ReadLine();
            WScript.StdOut.WriteLine(line);
            output += line + "\n";
        }
        if (!exec.StdErr.AtEndOfStream) {
            var errLine = exec.StdErr.ReadLine();
            WScript.StdErr.WriteLine("Error: " + errLine);
            error += errLine + "\n";
        }
        WScript.Sleep(100);
    }

    // Read any remaining output
    output += exec.StdOut.ReadAll();
    error += exec.StdErr.ReadAll();
    if (output && trim(output)) WScript.StdOut.WriteLine(output);
    if (error && trim(error)) WScript.StdErr.WriteLine("Error: " + error);
    return { exitCode: exec.ExitCode, output: output, error: error };
}

// Check if Python is installed (timeout after 10 seconds)
WScript.StdOut.WriteLine("Checking for Python...");
var pythonCheck = runCommand("python.exe --version", 10);
var pythonInstalled = pythonCheck.exitCode === 0;

if (!pythonInstalled) {
    WScript.StdOut.WriteLine("Python not found or check failed. Downloading installer...");
    var url = "https://www.python.org/ftp/python/3.11.4/python-3.11.4.exe";
    var filePath = "python_installer.exe";
    var http = new ActiveXObject("MSXML2.XMLHTTP");
    http.open("GET", url, false);
    http.send();
    if (http.status === 200) {
        var fs = new ActiveXObject("Scripting.FileSystemObject");
        var file = fs.CreateBinaryFile(filePath, true);
        file.Write(http.responseBody);
        file.Close();
        WScript.StdOut.WriteLine("Installing Python 3.11.4 silently...");
        var installResult = runCommand(".\\python_installer.exe /quiet PrependPath=1", 300); // 5-minute timeout, ensure PATH update
        if (installResult.exitCode === 0) {
            WScript.StdOut.WriteLine("Python installed successfully. Verifying...");
            pythonCheck = runCommand("python.exe --version", 10);
            pythonInstalled = pythonCheck.exitCode === 0;
        }
        if (!pythonInstalled) {
            WScript.StdErr.WriteLine("Python installation failed or not found after install. Please install Python manually from https://www.python.org/downloads/");
            WScript.Quit(1);
        }
    } else {
        WScript.StdErr.WriteLine("Failed to download Python installer from " + url + ". Please download and install Python manually from https://www.python.org/downloads/");
        WScript.Quit(1);
    }
}

// Inform user
WScript.StdOut.WriteLine("Python is installed: " + trim(pythonCheck.output));
WScript.StdOut.WriteLine("Python setup complete. To install required packages, run 'python -m pip install -r requirements.txt' in this directory.");
WScript.StdOut.WriteLine("Ensure requirements.txt is present and contains your dependencies.");